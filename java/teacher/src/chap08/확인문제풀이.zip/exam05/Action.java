package verify.exam05;

public interface Action {
	void work();
}
